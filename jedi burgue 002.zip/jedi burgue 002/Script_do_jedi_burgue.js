let carrinho = [];
let total = 0;
